/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['logo.clearbit.com', 'www.google.com'],
  },
}

module.exports = nextConfig
